# from dataclasses import dataclass
# import json
# import os
# from os.path import join
# import shlex
# import shutil
# import subprocess
# from typing import Any, Dict, List, Optional, Tuple
#
# import numpy
# import numpy as np
# import pandas as pd
# import SimpleITK as sitk
#
# from GreedyFHist.utils.io import create_if_not_exists, read_simple_vtk, write_coordinates_as_vtk, write_mat_to_file
# from GreedyFHist.segmentation.segmenation import segment_image
# from GreedyFHist.utils.image import (
#     call_command,
#     rescale_affine,
#     rescale_warp_test,
#     denoise_image,
#     apply_mask,
#     com_affine_matrix,
#     resample_image,
#     pad_image,
#     resample_image_with_gaussian
# )
# from GreedyFHist.utils.utils import build_cmd_string
#
#
# def get_four_corners_statistics(path_img, kernel, width, height, path_to_c2d):
#     width_minus_kernel = width - kernel
#     height_minus_kernel = height - kernel
#     # Four corners command
#     four_corners_command = f'{path_to_c2d} {path_img}  \
#     -dup -cmv -popas Y -popas X -push X -thresh 0 {kernel}  1 0 -push Y \
#     -thresh 0 {kernel} 1 0 -times -popas c00 -push X -thresh {width_minus_kernel}\
#     {width} 1 0 -push Y -thresh 0 {kernel} 1 0 -times -popas \
#     c01 -push X -thresh {width_minus_kernel} {width} \
#     1 0 -push Y -thresh {height_minus_kernel} {height} \
#     1 0 -times -popas c11 -push X -thresh 0 {kernel} 1 0 -push Y -thresh \
#     {height_minus_kernel} {height} 1 0 -times -popas c10 -push c00 -push c01 -push c11 -push c10 -add -add -add -lstat'
#     four_corners_ret = subprocess.run(shlex.split(four_corners_command), capture_output=True)
#     stats = four_corners_ret.stdout.decode('utf-8')
#     stats_tokens = stats.split('\n')[2].split()
#     mean = stats_tokens[1]
#     std = stats_tokens[2]
#     return mean, std
#
#
# def pad_with_sampled_background(path_to_c2d, image_path, width, height, out_path, mean, std, tmp_dir):
#     create_if_not_exists(tmp_dir)
#     # First resize
#     command_resize = f'{path_to_c2d} {image_path} -pad-to {width}x{height} 0 -o {out_path}'
#     ret = subprocess.run(command_resize.split(), capture_output=True)
#     # Then create mask
#     mask_path = join(tmp_dir, 'mask_padding_same_img_size.nii.gz')
#     ret = create_mask_of_size(path_to_c2d, image_path, width, height, mask_path)
#     ret = invert_mask_command(path_to_c2d, mask_path, mean, std)
#     ret = add_mask_padding_command(path_to_c2d, mask_path, out_path)
#     os.remove(mask_path)
#     return ret
#
#
# def create_mask_of_size(path_to_c2d,
#                         image_path,
#                         width,
#                         height,
#                         out_path):
#     cmd = f'{path_to_c2d} {image_path} -thresh 1 inf 1 0 -pad-to \
#     {width}x{height} 0 -o {out_path}'
#     ret = subprocess.run(shlex.split(cmd), capture_output=True)
#     return ret
#
#
# def create_mask_command(path_to_c2d,
#                         path_img_padded,
#                         four_kernel,
#                         path_mask):
#     cmd = f'{path_to_c2d} {path_img_padded} -thresh 1 inf 1 0 -pad \
#     {four_kernel}x{four_kernel} {four_kernel}x{four_kernel} 0 -o {path_mask}'
#     ret = subprocess.run(shlex.split(cmd), capture_output=True)
#     return ret
#
#
# def invert_mask_command(path_to_c2d,
#                         path_mask,
#                         mean,
#                         std):
#     cmd = f'{path_to_c2d} {path_mask} -replace 0 1 1 0 -popas invmask \
#     {path_mask} -replace 0 1 1 1 -scale {mean} -noise-gaussian {std} \
#     -push invmask -times -o {path_mask}'
#     ret = subprocess.run(shlex.split(cmd), capture_output=True)
#     return ret
#
#
# def pad_command(path_to_c2d,
#                 path_img_padded,
#                 four_kernel):
#     cmd = f'{path_to_c2d} {path_img_padded} -pad {four_kernel}x{four_kernel} \
#     {four_kernel}x{four_kernel} 0 -o {path_img_padded}'
#     ret = subprocess.run(shlex.split(cmd), capture_output=True)
#     return ret
#
#
# def add_mask_padding_command(path_to_c2d,
#                              path_mask,
#                              path_img_padded):
#     cmd = f'{path_to_c2d} {path_mask} {path_img_padded} -add -o {path_img_padded}'
#     ret = subprocess.run(shlex.split(cmd), capture_output=True)
#     return ret
#
#
# def preprocess_image(path_to_c2d,
#                      path_img_padded,
#                      four_kernel,
#                      path_mask,
#                      mean,
#                      std):
#     ret1 = create_mask_command(path_to_c2d, path_img_padded, four_kernel, path_mask)
#     ret2 = invert_mask_command(path_to_c2d, path_mask, mean, std)
#     ret3 = pad_command(path_to_c2d, path_img_padded, four_kernel)
#     ret4 = add_mask_padding_command(path_to_c2d, path_mask, path_img_padded)
#     return ret1, ret2, ret3, ret4
#
#
# def deformable_registration(path_to_greedy,
#                             path_fixed_image,
#                             path_moving_image,
#                             cost_fun,
#                             kernel,
#                             iteration_vec,
#                             s1,
#                             s2,
#                             output_warp=None,
#                             output_inv_warp=None,
#                             affine_pre_transform=None,
#                             additional_args=None
#                             ):
#     cost_fun_params = cost_fun
#     if cost_fun == 'ncc' or cost_fun == 'wncc':
#         cost_fun_params += f' {kernel}x{kernel}'
#     def_args = {}
#     def_args['-it'] = affine_pre_transform
#     def_args['-d'] = '2'
#     # def_args['-m'] = f'NCC {kernel}x{kernel}'
#     def_args['-m'] = cost_fun_params
#     def_args['-i'] = [path_fixed_image, path_moving_image]
#     def_args['-n'] = f'{iteration_vec[0]}x{iteration_vec[1]}x{iteration_vec[2]}'
#     def_args['-threads'] = '32'
#     def_args['-s'] = [f'{s1}vox', f'{s2}vox']
#     def_args['-o'] = output_warp
#     def_args['-oinv'] = output_inv_warp
#     if '-sv' in additional_args:
#         def_args['-sv'] = ''
#     elif '-svlb' in additional_args:
#         def_args['-svlb'] = ''
#
#     def_cmd = build_cmd_string(path_to_greedy, def_args)
#     def_ret = call_command(def_cmd)
#     return def_ret
#
#
# def affine_registration(path_to_greedy,
#                         path_to_fixed_image,
#                         path_to_moving_image,
#                         path_output,
#                         offset,
#                         iteration_vec,
#                         iteration_rigid,
#                         cost_fun,
#                         ia,
#                         kernel=None
#                         ):
#     cost_fun_params = cost_fun
#     if cost_fun == 'ncc' or cost_fun == 'wncc':
#         cost_fun_params += f' {kernel}x{kernel}'
#     aff_rgs = {}
#     aff_rgs['-d'] = '2'
#     aff_rgs['-i'] = [path_to_fixed_image, path_to_moving_image]
#     aff_rgs['-o'] = path_output
#     # aff_rgs['-m'] = f'NCC {kernel}x{kernel}'
#     aff_rgs['-m'] = cost_fun_params
#     aff_rgs['-n'] = f'{iteration_vec[0]}x{iteration_vec[1]}x{iteration_vec[2]}'
#     aff_rgs['-threads'] = '32'
#     aff_rgs['-dof'] = '12'
#     aff_rgs['-search'] = f'{iteration_rigid} 180 {offset}'.split()  # Replaced 360 with any for rotation parameter
#     aff_rgs['-gm-trim'] = f'{kernel}x{kernel}'
#     aff_rgs['-a'] = ''  # Doesnt get param how to parse?
#     aff_rgs[ia[0]] = ia[1]
#
#     aff_cmd = build_cmd_string(path_to_greedy, aff_rgs)
#     aff_ret = call_command(aff_cmd)
#     return aff_ret
#
#
# # Warp functions
#
# def warp_image_data(fixed_image_path,
#                     moving_image_path,
#                     output_image_path,
#                     transforms,
#                     path_to_greedy,
#                     path_to_c2d,
#                     temp_dir,
#                     interpolation_mode='LINEAR'):
#     # TODO: Is this command just copying images into a new folder?
#     fixed_fname = os.path.basename(fixed_image_path)
#     path_new_target = os.path.join(temp_dir, fixed_fname + '_new_target.nii.gz')
#     cmd = f"""{path_to_c2d} -mcs '{fixed_image_path}' -foreach -orient LP -spacing 1x1mm -origin 0x0mm -endfor -omc '{path_new_target}'"""
#     fixed_pre_ret = call_command(cmd)
#
#     moving_fname = os.path.basename(moving_image_path)
#     path_new_source = os.path.join(temp_dir, moving_fname + '_new_source.nii.gz')
#     cmd = f"""{path_to_c2d} -mcs '{moving_image_path}' -foreach -orient LP -spacing 1x1mm -origin 0x0mm -endfor -omc '{path_new_source}'"""
#     moving_pre_ret = call_command(cmd)
#
#     # PATH_registered_iamge = os.path.join(PATH_niftis_full, 'registeredImage.nii.gz')
#
#     # For small resolution
#
#     big_reslice_args = {}
#     big_reslice_args['-r'] = transforms
#     big_reslice_args['-d'] = '2'
#     big_reslice_args['-rf'] = path_new_target
#     big_reslice_args['-rm'] = [path_new_source, output_image_path]
#     big_reslice_args['-ri'] = [interpolation_mode]
#
#     big_reslice_cmd = build_cmd_string(path_to_greedy, big_reslice_args)
#     big_reslice_ret = call_command(big_reslice_cmd)
#     return [fixed_pre_ret, moving_pre_ret, big_reslice_ret]
#
#
# def map_infs_back(warped_landmarks, source_landmarks):
#     infs = (source_landmarks.x_small == np.inf) | (source_landmarks.y_small == np.inf)
#     infs = infs.to_numpy()
#     warped_landmarks.x.loc[infs] = np.inf
#     warped_landmarks.y.loc[infs] = np.inf
#     return warped_landmarks
#
#
# def transform_landmarks(path_to_greedy,
#                         path_landmarks,
#                         output_path,
#                         path_temp,
#                         paths_to_inv_transforms,
#                         path_small_moving,
#                         width_downscale,
#                         height_downscale,
#                         additional_args=None):
#     # Apply transformation to landmarks
#     if additional_args is None:
#         additional_args = {}
#     path_small_landmarks = os.path.join(path_temp, 'lm_small_source.vtk')
#     df_lm = pd.read_csv(path_landmarks)
#     # First scale down
#     df_lm['x_small'] = df_lm.x * 1.0 * width_downscale - 0.5
#     df_lm['y_small'] = df_lm.y * 1.0 * height_downscale - 0.5
#     write_coordinates_as_vtk(df_lm[['x_small', 'y_small']].to_numpy(), path_small_landmarks)
#
#     path_small_warped_landmarks = os.path.join(path_temp, 'lm_small_source_warped.vtk')
#     transform_params = {}
#     transform_params['width_downscale'] = width_downscale
#     transform_params['height_downscale'] = height_downscale
#
#     # Second, warp.
#     # TODO: Can this be done with big warp as well???
#     # TODO: And why do I need interpolation?
#
#     interpolation_mode = 'NN' if 'interpolation_mode' not in additional_args else additional_args['interpolation_mode']
#
#     lm_args = {}
#     lm_args['-rs'] = [path_small_landmarks, path_small_warped_landmarks]
#     lm_args['-r'] = paths_to_inv_transforms
#     lm_args['-d'] = '2'
#     lm_args['-rf'] = path_small_moving
#     lm_args['-ri'] = interpolation_mode
#
#     transform_params['interpolation_mode'] = interpolation_mode
#
#     lm_cmd = build_cmd_string(path_to_greedy, lm_args)
#     lm_ret = call_command(lm_cmd)
#     cmdl_returns = [lm_ret]
#
#     # Third, scale up
#     # df_small_warped_lm = pd.read_csv(path_small_warped_landmarks, header=None)
#     small_warped_lm = read_simple_vtk(path_small_warped_landmarks)
#     df_small_warped_lm = pd.DataFrame(small_warped_lm)
#     df_small_warped_lm.rename(columns={0: 'small_x', 1: 'small_y'}, inplace=True)
#     df_small_warped_lm['x'] = (df_small_warped_lm.small_x + 0.5) * (1 / width_downscale)
#     df_small_warped_lm['y'] = (df_small_warped_lm.small_y + 0.5) * (1 / height_downscale)
#     df_small_warped_lm.drop(columns=['small_x', 'small_y'], inplace=True)
#     df_small_warped_lm = map_infs_back(df_small_warped_lm, df_lm)
#     # df_small_warped_lm.to_csv(output_path, index=False)
#     transform_params['width_upscale'] = 1 / width_downscale
#     transform_params['height_upscale'] = 1 / height_downscale
#
#     transformation_result = PointcloudTransformationResult(
#         pointcloud=df_small_warped_lm,
#         pointcloud_path=output_path,
#         cmdl_log=cmdl_returns,
#         transform_params=transform_params
#     )
#
#     return transformation_result
#
#
# @dataclass
# class RegResult:
#     path_to_small_affine: str
#     path_to_big_affine: str
#     path_to_small_warp: str
#     path_to_big_warp: str
#     path_to_small_inv_warp: str
#     path_to_big_inv_warp: str
#     width_downscaling_factor: float
#     height_downscaling_factor: float
#     path_to_small_fixed: str
#     path_to_small_moving: str
#     cmdl_log: Optional[List[subprocess.CompletedProcess]]
#     reg_params: Optional[Any]
#
#
# @dataclass
# class PointcloudTransformationResult:
#     pointcloud: Optional[Any]
#     pointcloud_path: str
#     cmdl_log: Optional[List[subprocess.CompletedProcess]]
#     transform_params: Optional[Any]
#
#
# @dataclass
# class ImageTransformationResult:
#     registered_image: Optional[numpy.array]
#     registered_image_path: str
#     cmdl_log: Optional[List[subprocess.CompletedProcess]]
#     transform_params: Optional[Any]
#
#
# @dataclass
# class PreprocessedData:
#     image_path: str
#     height: int
#     width: int
#     height_padded: int
#     width_padded: int
#     height_original: int
#     width_original: int
#     cmdl_log: Optional[List[subprocess.CompletedProcess]]
#
#
# @dataclass
# class PreprocessedData2:
#     image: numpy.array
#     height: int
#     width: int
#     height_padded: int
#     width_padded: int
#     height_original: int
#     width_original: int
#
#
# @dataclass
# class GreedyFHist:
#     name: str = 'GreedyFHist'
#     path_to_c2d: str = ''
#     path_to_greedy: str = ''
#     path_temp: str = 'tmp'
#     path_output: str = 'out'
#
#     def resample_warp(self,
#                       input_path,
#                       output_path,
#                       width,
#                       height,
#                       factor
#                       ):
#         cmd = f'{self.path_to_c2d} -mcs {input_path} -foreach -resample {width}x{height} -scale {factor} -spacing 1x1mm -origin 0x0mm -endfor -omc {output_path}'
#         ret = call_command(cmd)
#         return ret
#
#     def preprocess_image(self,
#                          path_img_padded,
#                          four_kernel,
#                          path_mask,
#                          mean,
#                          std):
#         path_mask = os.path.join(self.path_temp, 'mask.nii.gz')
#         ret1 = create_mask_command(self.path_to_c2d, path_img_padded, four_kernel, path_mask)
#         ret2 = invert_mask_command(self.path_to_c2d, path_mask, mean, std)
#         ret3 = pad_command(self.path_to_c2d, path_img_padded, four_kernel)
#         ret4 = add_mask_padding_command(self.path_to_c2d, path_mask, path_img_padded)
#         os.remove(path_mask)
#         return ret1, ret2, ret3, ret4
#
#
#     def __do_all_preprocessing(self,
#                                image: numpy.array,
#                                kernel: int,
#                                resample: float,
#                                smoothing: int,
#                                tmp_dir: str):
#
#         # 1. Set up directories and filenames
#         cmdln_returns = []
#         create_if_not_exists(tmp_dir)
#         input_img_path = join(tmp_dir, 'input_image.nii.gz')
#         sitk.WriteImage(sitk.GetImageFromArray(image, True), input_img_path)
#         sitk_image = sitk.ReadImage(input_img_path)
#         height_image = sitk_image.GetHeight()
#         width_image = sitk_image.GetWidth()
#         path_small_image = join(tmp_dir, 'new_small_image.nii.gz')
#         path_image = join(tmp_dir, 'converted_image.nii.gz')
#         sitk.WriteImage(sitk_image, path_image)
#
#         ret_resampling = resample_image(self.path_to_c2d, path_image, path_small_image, resample, smoothing)
#         cmdln_returns.append(ret_resampling)
#
#         # 2. Preprocessing Step 2: Add padding for out of bounce. Estimate padded background by taking pixel information from background.
#         small_image = sitk.ReadImage(path_small_image)
#         height_small_image = small_image.GetHeight()
#         width_small_image = small_image.GetWidth()
#
#         bck_mean, bck_std = get_four_corners_statistics(path_small_image, kernel, width_small_image, height_small_image,
#                                                         self.path_to_c2d)
#         four_kernel = kernel * 4
#
#         # path_small_image_padded = os.path.join(tmp_dir, 'new_small_target_padded.nii.gz')
#         path_small_image_padded = path_small_image
#         path_mask = os.path.join(tmp_dir, 'mask.nii.gz')
#
#         ret_preprocess_image = preprocess_image(self.path_to_c2d,
#                                                 path_small_image_padded,
#                                                 four_kernel,
#                                                 path_mask,
#                                                 bck_mean,
#                                                 bck_std)
#
#         cmdln_returns.append(ret_preprocess_image)
#
#         img_padded = sitk.ReadImage(path_small_image_padded)
#         width_image_padded = img_padded.GetWidth()
#         height_image_padded = img_padded.GetHeight()
#
#         preprocessed_data = PreprocessedData(
#             image_path=path_small_image_padded,
#             height=height_small_image,
#             width=width_small_image,
#             height_padded=height_image_padded,
#             width_padded=width_image_padded,
#             height_original=height_image,
#             width_original=width_image,
#             cmdl_log=cmdln_returns
#         )
#         return preprocessed_data
#
#     def register(self,
#                  moving_img: numpy.array,
#                  fixed_img: numpy.array,
#                  moving_img_mask: Optional[numpy.array] = None,
#                  fixed_img_mask: Optional[numpy.array] = None,
#                  args: Optional[Dict[Any, Any]] = None) -> Any:
#         # Step 1: Set up all the parameters and filenames as necessary.
#         path_output = args.get('output_dir', 'out')
#         self.path_output = path_output
#         path_temp = args.get('tmp_dir', 'tmp')
#         self.path_temp = path_temp
#         create_if_not_exists(path_temp)
#         cleanup_temporary_directories = args.get('cleanup_temporary_directories', True)
#         s1 = args.get('s1', 6.0)
#         s2 = args.get('s2', 5.0)
#         resolution = int(args.get('resolution', 1024))  # Changed from 512
#         resample = resolution / moving_img.shape[0] * 100
#         kernel = args.get('kernel', 10)
#         iteration_rigid = args.get('iteration_rigid', 10000)
#         affine_init = args.get('ia', 'ia-image-centers')
#         cost_fun = args.get('cost_fun', 'ncc').lower()
#         store_cmdl_returns = args.get('store_cmdl_returns', True)
#         affine_use_denoising = args.get('affine_use_denoising', True)
#         deformable_use_denoising = args.get('deformable_use_denoising', False)
#
#         smoothing = max(int(100 / (2 * resample)), 1)
#
#         reg_params = {'resample': resample,
#                       's1': s1,
#                       's2': s2,
#                       'iteration_rigid': iteration_rigid,
#                       'resolution': resolution,
#                       'smoothing': smoothing,
#                       'affine_use_denoising': affine_use_denoising,
#                       'deformable_use_denoising': deformable_use_denoising,
#                       'args': args
#                       }
#
#         cmdln_returns = []
#         try:
#             if moving_img_mask is None:
#                 moving_img_mask = segment_image(moving_img)
#             if fixed_img_mask is None:
#                 fixed_img_mask = segment_image(fixed_img)
#             moving_img = apply_mask(moving_img, moving_img_mask)
#             fixed_img = apply_mask(fixed_img, fixed_img_mask)
#             requires_denoising = affine_use_denoising or deformable_use_denoising
#             requires_standard_preprocessing = (not affine_use_denoising) or (not deformable_use_denoising)
#             if requires_denoising:
#                 mov_sr = args.get('mov_sr', 30)
#                 mov_sp = args.get('mov_sp', 20)
#                 moving_img_denoised = denoise_image(moving_img, sp=mov_sp, sr=mov_sr)
#
#                 fix_sr = args.get('fix_sr', 30)
#                 fix_sp = args.get('fix_sp', 20)
#                 fixed_img_denoised = denoise_image(fixed_img, sp=fix_sp, sr=fix_sr)
#
#                 moving_denoised_tmp_dir = join(path_temp, 'moving_denoised')
#                 create_if_not_exists(moving_denoised_tmp_dir)
#                 moving_denoised_preprocessed = self.__do_all_preprocessing(moving_img_denoised, kernel, resample,
#                                                                            smoothing, moving_denoised_tmp_dir)
#                 cmdln_returns.append(moving_denoised_preprocessed.cmdl_log)
#
#                 fixed_denoised_tmp_dir = join(path_temp, 'fixed_denoised')
#                 create_if_not_exists(fixed_denoised_tmp_dir)
#                 fixed_denoised_preprocessed = self.__do_all_preprocessing(fixed_img_denoised, kernel, resample,
#                                                                           smoothing,
#                                                                           fixed_denoised_tmp_dir)
#                 cmdln_returns.append(fixed_denoised_preprocessed.cmdl_log)
#             # 1. Set up directories and filenames
#             if requires_standard_preprocessing:
#                 # Metrics
#                 moving_tmp_dir = join(path_temp, 'moving')
#                 create_if_not_exists(moving_tmp_dir)
#                 moving_img_preprocessed = self.__do_all_preprocessing(moving_img, kernel, resample, smoothing,
#                                                                       moving_tmp_dir)
#                 cmdln_returns.append(moving_img_preprocessed.cmdl_log)
#
#                 fixed_tmp_dir = join(path_temp, 'fixed')
#                 create_if_not_exists(fixed_tmp_dir)
#                 fixed_img_preprocessed = self.__do_all_preprocessing(fixed_img, kernel, resample, smoothing,
#                                                                      fixed_tmp_dir)
#                 cmdln_returns.append(fixed_img_preprocessed.cmdl_log)
#
#             path_metrics = os.path.join(path_output, 'metrics')
#             path_metrics_small_resolution = os.path.join(path_metrics, 'small_resolution')
#             path_metrics_full_resolution = os.path.join(path_metrics, 'full_resolution')
#
#             create_if_not_exists(path_output)
#             create_if_not_exists(path_temp)
#             create_if_not_exists(path_metrics)
#             create_if_not_exists(path_metrics_small_resolution)
#             create_if_not_exists(path_metrics_full_resolution)
#
#             # 3. Registration
#
#             # Affine registration
#             path_small_affine = os.path.join(path_metrics_small_resolution, 'small_affine.mat')
#             offset = int((fixed_img_preprocessed.height + (kernel * 4)) / 10)
#             iteration_vec = [100, 50, 10]
#             reg_params['offset'] = offset
#             reg_params['iteration_vec'] = iteration_vec
#
#             ia_init = ''
#             if affine_init == 'ia-com-init' and fixed_img_mask is not None and moving_img_mask is not None:
#                 # Use Segmentation masks to compute center of mass initialization
#                 # Check that masks are np.arrays
#                 init_mat_path = os.path.join(path_temp, 'Affine_init.mat')
#                 init_mat = com_affine_matrix(fixed_img_mask, moving_img_mask)
#                 write_mat_to_file(init_mat, init_mat_path)
#                 ia_init = ['-ia', f'{init_mat_path}']
#             elif affine_init == 'ia-image-centers':
#                 ia_init = ['-ia-image-centers', '']
#             else:
#                 print(f'Uknown ia option: {affine_init}.')
#
#             if affine_use_denoising:
#                 fixed_img_path = fixed_denoised_preprocessed.image_path
#                 moving_img_path = moving_denoised_preprocessed.image_path
#             else:
#                 fixed_img_path = fixed_img_preprocessed.image_path
#                 moving_img_path = moving_img_preprocessed.image_path
#
#             aff_ret = affine_registration(self.path_to_greedy,
#                                           fixed_img_path,
#                                           moving_img_path,
#                                           path_small_affine,
#                                           offset,
#                                           iteration_vec,
#                                           iteration_rigid,
#                                           cost_fun,
#                                           ia=ia_init,
#                                           kernel=kernel)
#
#             cmdln_returns.append(aff_ret)
#
#             # Diffeomorphic
#             if affine_use_denoising and not deformable_use_denoising:
#                 # Map paths back
#                 fixed_img_path = fixed_img_preprocessed.image_path
#                 moving_img_path = moving_img_preprocessed.image_path
#
#             path_small_warp = os.path.join(path_metrics_small_resolution, 'small_warp.nii.gz')
#             path_small_warp_inv = os.path.join(path_metrics_small_resolution, 'small_inv_warp.nii.gz')
#
#             deformable_reg_ret = deformable_registration(self.path_to_greedy,
#                                                          fixed_img_path,
#                                                          moving_img_path,
#                                                          cost_fun,
#                                                          kernel,
#                                                          iteration_vec,
#                                                          s1,
#                                                          s2,
#                                                          output_warp=path_small_warp,
#                                                          output_inv_warp=path_small_warp_inv,
#                                                          affine_pre_transform=path_small_affine,
#                                                          additional_args=args)
#             cmdln_returns.append(deformable_reg_ret)
#
#             factor = 100 / resample
#             reg_params['factor'] = factor
#
#             path_affine = os.path.join(path_metrics_full_resolution, 'Affine.mat')
#             rescale_affine(path_small_affine, path_affine, factor)
#
#             reg_params['WIDTH_small_fixed'] = fixed_img_preprocessed.width
#             reg_params['HEIGHT_small_fixed'] = fixed_img_preprocessed.height
#             reg_params['WIDTH_fixed_image_padded'] = fixed_img_preprocessed.width_padded
#             reg_params['HEIGHT_fixed_image_padded'] = fixed_img_preprocessed.height_padded
#             reg_params['WIDTH_fixed_image'] = fixed_img_preprocessed.width_original
#             reg_params['HEIGHT_fixed_image'] = fixed_img_preprocessed.height_original
#
#             path_big_warp = os.path.join(path_metrics_full_resolution, 'big_warp.nii.gz')
#             rescale_warp_ret = rescale_warp_test(self.path_to_c2d,
#                                                  path_small_warp,
#                                                  path_big_warp,
#                                                  (fixed_img_preprocessed.width, fixed_img_preprocessed.height),
#                                                  (fixed_img_preprocessed.width_padded,
#                                                   fixed_img_preprocessed.height_padded),
#                                                  (fixed_img_preprocessed.width_original,
#                                                   fixed_img_preprocessed.height_original),
#                                                  factor,
#                                                  temp_path=path_temp,
#                                                  cleanup=False)
#
#             reg_params['WIDTH_small_moving'] = moving_img_preprocessed.width
#             reg_params['HEIGHT_small_moving'] = moving_img_preprocessed.height
#             reg_params['WIDTH_moving_image_padded'] = moving_img_preprocessed.width_padded
#             reg_params['HEIGHT_moving_image_padded'] = moving_img_preprocessed.height_padded
#             reg_params['WIDTH_moving_image'] = moving_img_preprocessed.width_original
#             reg_params['HEIGHT_moving_image'] = moving_img_preprocessed.height_original
#
#             path_big_warp_inv = os.path.join(path_metrics_full_resolution, 'big_warp_inv.nii.gz')
#             rescale_inv_warp_ret = rescale_warp_test(self.path_to_c2d,
#                                                      path_small_warp_inv,
#                                                      path_big_warp_inv,
#                                                      (moving_img_preprocessed.width, moving_img_preprocessed.height),
#                                                      (moving_img_preprocessed.width_padded,
#                                                       moving_img_preprocessed.height_padded),
#                                                      (moving_img_preprocessed.width_original,
#                                                       moving_img_preprocessed.height_original),
#                                                      factor,
#                                                      temp_path=path_temp,
#                                                      cleanup=False)
#
#             cmdln_returns.append(rescale_warp_ret)
#             cmdln_returns.append(rescale_inv_warp_ret)
#
#             if cleanup_temporary_directories:
#                 self.__cleanup_temporary_directory(path_temp)
#             # Check those 2
#
#             width_downscale = fixed_img_preprocessed.width / fixed_img_preprocessed.width_original
#             height_downscale = fixed_img_preprocessed.height / fixed_img_preprocessed.height_original
#
#             reg_params['width_downscaling_factor'] = width_downscale
#             reg_params['height_downscaling_factor'] = height_downscale
#
#             reg_param_outpath = os.path.join(path_output, 'reg_params.json')
#             with open(reg_param_outpath, 'w') as f:
#                 json.dump(reg_params, f)
#
#             if store_cmdl_returns:
#                 cmd_output = os.path.join(path_output, 'cmdl_returns.txt')
#                 with open(cmd_output, 'w') as f:
#                     for ret in cmdln_returns:
#                         f.write(f'{ret}\n')
#
#             reg_result = RegResult(
#                 path_to_small_affine=path_small_affine,
#                 path_to_big_affine=path_affine,
#                 path_to_small_warp=path_small_warp,
#                 path_to_big_warp=path_big_warp,
#                 path_to_small_inv_warp=path_small_warp_inv,
#                 path_to_big_inv_warp=path_big_warp_inv,
#                 width_downscaling_factor=width_downscale,
#                 height_downscaling_factor=height_downscale,
#                 path_to_small_moving=moving_img_preprocessed.image_path,
#                 path_to_small_fixed=fixed_img_preprocessed.image_path,
#                 cmdl_log=cmdln_returns,
#                 reg_params=reg_params
#             )
#
#             return reg_result
#         except Exception as e:
#             print(e)
#             return cmdln_returns
#
#     def transform_image(self,
#                         image: numpy.array,
#                         transformation: RegResult,
#                         interpolation_mode: str,
#                         args: Optional[Dict[Any, Any]] = None) -> Any:
#         # TODO: Is this command just copying images into a new folder?
#         if args is None:
#             args = {}
#         tmp_dir = args.get('tmp_dir', 'tmp')
#         create_if_not_exists(tmp_dir)
#         remove_temp_directory = args.get('remove_temp_directory', True)
#         output_image_path = join(tmp_dir, 'registered_image.nii.gz')
#         out_image_pixel_type = sitk.sitkUInt64 if image.dtype.name == 'uint64' else -1
#         cmdl_returns = []
#         transform_params = {}
#         transform_params['out_image_pixel_type'] = out_image_pixel_type
#         # Setup reference image ---- Not using a reference image anymore. Instead just use the moving image. This only works if we assume that reference space is
#         # the same as the moving image space, i.e. the same resolution.
#
#         moving_fname = 'transform_moving.nii.gz'
#         # moving_old_fname = 'transform_old_moving.png'
#         moving_old_fname = 'transform_old_moving.nii.gz'
#         PATH_old_source = os.path.join(tmp_dir, moving_old_fname)
#         PATH_new_source = os.path.join(tmp_dir, moving_fname)
#         # sitk.WriteImage(sitk.GetImageFromArray(image), PATH_old_source)
#         # io.imsave(PATH_old_source, image)
#         # image = pad_image(image, transformation.reg_params['moving_img_padding'])
#         sitk.WriteImage(sitk.GetImageFromArray(image, True), PATH_old_source)
#         cmd = f"""{self.path_to_c2d} -mcs '{PATH_old_source}' -foreach -orient LP -spacing 1x1mm -origin 0x0mm -endfor -omc '{PATH_new_source}'"""
#         moving_pre_ret = call_command(cmd)
#         cmdl_returns.append(moving_pre_ret)
#
#         transforms = [transformation.path_to_big_warp, transformation.path_to_big_affine]
#         transform_params['transforms'] = transforms
#         interpolation_mode = args.get('interpolation_mode', 'LINEAR')
#         rb = args.get('rb', 0)
#         transform_params['interpolation_mode'] = interpolation_mode
#         big_reslice_args = {}
#         big_reslice_args['-r'] = transforms
#         big_reslice_args['-d'] = '2'
#         # big_reslice_args['-rf'] = PATH_new_target
#         big_reslice_args['-rf'] = PATH_new_source
#         big_reslice_args['-rm'] = [PATH_new_source, output_image_path]
#         big_reslice_args['-ri'] = [interpolation_mode]
#         big_reslice_args['-rb'] = f'{rb}'
#
#         big_reslice_cmd = build_cmd_string(self.path_to_greedy, big_reslice_args)
#         big_reslice_ret = call_command(big_reslice_cmd)
#         registered_image = sitk.GetArrayFromImage(sitk.ReadImage(output_image_path, out_image_pixel_type))
#         # We get images back that are floats in the 0-255 range.
#         registered_image = registered_image.astype(int)
#         # If the image has 3 colour channels convert back to ints.
#         if len(registered_image.shape) == 2:
#             registered_image = registered_image.astype(np.int32)
#         cmdl_returns.append(big_reslice_ret)
#         if remove_temp_directory:
#             self.__cleanup_temporary_directory(tmp_dir)
#         transform_ret = ImageTransformationResult(
#             registered_image=registered_image,
#             registered_image_path=output_image_path,
#             cmdl_log=cmdl_returns,
#             transform_params=transform_params
#         )
#         return transform_ret
#
#     def transform_coordinates(self,
#                               coordinates,
#                               transformation: Any,
#                               args=None) -> Any:
#         if args is None:
#             args = {}
#         tmp_dir = args.get('tmp_dir', 'tmp')
#         output_path = args.get('output_path', join(tmp_dir, 'registered_pc.csv'))
#         create_if_not_exists(tmp_dir)
#         remove_temp_directory = args.get('remove_temp_directory', True)
#         PATH_landmarks = os.path.join(tmp_dir, 'pointcloud.csv')
#         # pointcloud = pad_pointcloud(pointcloud, transformation.reg_params['moving_img_padding'])
#         coordinates.to_csv(PATH_landmarks)
#         width_downscale = transformation.width_downscaling_factor
#         height_downscale = transformation.height_downscaling_factor
#         paths_to_inv_transforms = [f'{transformation.path_to_small_affine},-1', transformation.path_to_small_inv_warp]
#         path_small_moving = transformation.path_to_small_moving
#         transform_res = transform_landmarks(self.path_to_greedy,
#                                             PATH_landmarks,
#                                             output_path,
#                                             tmp_dir,
#                                             paths_to_inv_transforms,
#                                             path_small_moving,
#                                             width_downscale,
#                                             height_downscale)
#         if remove_temp_directory:
#             self.__cleanup_temporary_directory(tmp_dir)
#         return transform_res
#
#     def __cleanup_temporary_directory(self, directory):
#         shutil.rmtree(directory)
#
#     @classmethod
#     def load_from_config(cls, config: Dict[str, Any]) -> 'GreedyFHist':
#         path_to_c2d = config['path_to_c2d']
#         path_to_greedy = config['path_to_greedy']
#         return cls(path_to_c2d=path_to_c2d, path_to_greedy=path_to_greedy)
